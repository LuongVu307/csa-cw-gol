package gol

import (
	"uk.ac.bris.cs/gameoflife/util"
)

// Params provides the details of how to run the Game of Life and which image to load.
type Params struct {
	Turns       int
	Threads     int
	ImageWidth  int
	ImageHeight int
}
type KeyChannels struct {
	SaveSig         chan bool
	PauseUnpauseSig chan bool
	QuitSig         chan bool
}

// FOR PARALLEL DOUBLE BUFFER
func defaultWorker(slice [][]uint8, resChan chan [][]uint8) {
	resChan <- calculateResultSliceForWorker(slice)
}
func defaultWorkerSingleThread(p Params, world [][]uint8, res [][]uint8) {
	calculateNextState(p, world, res)
}
func distributeWithDoubleBuffer(p Params, world [][]uint8, c distributorChannels, keyPresses KeyChannels) {

	world2 := Make2DSlice(p.ImageWidth, p.ImageHeight)
	doubleBufferTurnFn := func(p Params, world *[][]uint8) {
		startWorkersDoubleBuffer(p, *world, world2, defaultWorkerSingleThread, defaultWorker)
		*world, world2 = world2, *world
	}

	distributor(p, world, c, keyPresses, doubleBufferTurnFn)
}

// FOR PARALLEL MAP REDUCE
func MapReduceDefaultWorker(startY int, slice [][]uint8, resChan chan util.Cell) {
	cs := CalculateFlippedCellsForWorkerMapReduce(slice, startY)
	for i := 0; i < len(cs); i++ {
		resChan <- cs[i]
	}
}
func MapReduceDefaultWorkerSingleThread(p Params, world [][]uint8) []util.Cell {
	return CalculateCellsFlippedMapReduce(p, world)
}
func distributeWithMapReduce(p Params, world [][]uint8, c distributorChannels, keyPresses KeyChannels) {
	cellsFlippedBuffer := make([]util.Cell, 0)
	mapReduceTurnFn := func(p Params, world *[][]uint8) {
		size := 0
		StartWorkersMapReduce(p, *world, MapReduceDefaultWorkerSingleThread, MapReduceDefaultWorker, &cellsFlippedBuffer, &size)
	}

	distributor(p, world, c, keyPresses, mapReduceTurnFn)
}

// Run starts the processing of Game of Life. It should initialise channels and goroutines.
func Run(p Params, world [][]uint8, io IoChannels) {
	//	TODO: Put the missing channels in here.

	distributorChannels := distributorChannels{
		results: io.Results,
		ticker:  io.Ticker,
	}

	// TODO uncomment the preferred function below (and comment out the rest)
	distributeWithMapReduce(p, world, distributorChannels, io.KeyPresses)
	// distributeWithMapReduce(p, distributorChannels, keyPresses)
}
