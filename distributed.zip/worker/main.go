package main

import (
	"errors"
	"fmt"
	"log"
	"os"
	"os/signal"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"net"
	"net/rpc"
	"uk.ac.bris.cs/gameoflife/gol"
	"uk.ac.bris.cs/gameoflife/util"
)

// TODO allow broker to have multiple connections, net/rpc does not seem to work for this (to my knowledge)
type Worker struct {
	listener net.Listener
}
type WorkerArgs struct {
	StartY int
	Slice  [][]uint8
}

func (b *Worker) ProcessSliceMapReduce(args WorkerArgs, res *[]util.Cell) error {
	*res = gol.CalculateFlippedCellsForWorkerMapReduce(args.Slice, args.StartY)
	return nil
}

func (w *Worker) Shutdown(_ int, res *bool) error {
	*res = true
	return w.listener.Close()
}

// main is the function called when starting Game of Life with 'go run .'
func main() {

	worker := Worker{}
	rpc.Register(&worker)

	go sigint()

	if len(os.Args) == 1 {
		panic("Not enough arguments")
	}
	port := os.Args[1]
	listener, err := net.Listen("tcp", ":"+port)
	fmt.Println("Listening on port ", port)
	if err != nil {
		log.Fatal(err)
	}
	worker.listener = listener
	// Keep the process alive until the shutdown reply has been sent.
	var connections sync.WaitGroup
	for {
		conn, err := listener.Accept()
		if err != nil {
			if !errors.Is(err, net.ErrClosed) {
				log.Print(err)
			}
			break
		}
		connections.Go(func() { defer conn.Close(); rpc.ServeConn(conn) })
	}
	connections.Wait()
}

func sigint() {
	sigint := make(chan os.Signal, 1)
	signal.Notify(sigint, syscall.SIGINT, syscall.SIGTERM)
	var exit atomic.Bool
	for range sigint {
		if exit.Load() {
			log.Printf("[Main] %v Force quit by the user", util.Yellow("WARN"))
			os.Exit(0)
		} else {
			log.Printf("[Main] %v Press Ctrl+C again to force quit", util.Yellow("WARN"))
			exit.Store(true)
			go func() {
				time.Sleep(4 * time.Second)
				exit.Store(false)
			}()
		}
	}
}
