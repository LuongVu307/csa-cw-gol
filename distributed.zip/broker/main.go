package main

import (
	"errors"
	"fmt"
	"log"
	"os"
	"os/signal"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"net"
	"net/rpc"
	"uk.ac.bris.cs/gameoflife/gol"
	"uk.ac.bris.cs/gameoflife/util"
)

// TODO allow broker to have multiple connections, net/rpc does not seem to work for this (to my knowledge)
type Broker struct {
	// mtx   *sync.RWMutex
	// conns map[int]net.Conn
	Io                gol.IoChannels
	listener          net.Listener
	shutdownRequested atomic.Bool
	streamMu          sync.Mutex
	stream            *turnStream
}
type BrokerArgs struct {
	P     gol.Params
	World [][]uint8
}

type CompleteResult struct {
	Turn int
	Res  [][]uint8
}

func (b *Broker) ProcessConnection(args BrokerArgs, res *CompleteResult) error {
	fmt.Println("processing world")
	if b.Io.LiveView != nil {
		b.Io.LiveView.Start(args.P, args.World)
	}
	gol.Run(args.P, args.World, b.Io)
	completeRes := <-b.Io.Results.CompleteResult
	*res = CompleteResult{
		Turn: completeRes.Turn,
		Res:  completeRes.World,
	}
	fmt.Println("Finished processing world")
	return nil
}

// A bounded stream preserves every turn without retaining the whole simulation.
type turnStream struct {
	turns    chan []util.Cell
	released chan struct{}
	result   CompleteResult
	turn     int
}

type TurnResult struct {
	Turn  int
	Cells []util.Cell
	Done  bool
	Res   [][]uint8
}

func (b *Broker) ProcessStart(args BrokerArgs, res *bool) error {
	b.streamMu.Lock()
	defer b.streamMu.Unlock()
	// A test or controller may reconnect while the preceding controller is
	// still draining its final events. Wait for that session to finish.
	for b.stream != nil {
		released := b.stream.released
		b.streamMu.Unlock()
		<-released
		b.streamMu.Lock()
	}
	stream := &turnStream{turns: make(chan []util.Cell, 1), released: make(chan struct{})}
	b.stream = stream
	io := b.Io
	io.Turns = stream.turns
	go func() {
		gol.Run(args.P, args.World, io)
		result := <-io.Results.CompleteResult
		stream.result = CompleteResult{Turn: result.Turn, Res: result.World}
		close(stream.turns)
	}()
	*res = true
	return nil
}

func (b *Broker) ProcessNextTurn(_ int, res *TurnResult) error {
	b.streamMu.Lock()
	defer b.streamMu.Unlock()
	stream := b.stream
	if stream == nil {
		return errors.New("no simulation is running")
	}
	cells, ok := <-stream.turns
	if ok {
		stream.turn++
		*res = TurnResult{Turn: stream.turn, Cells: cells}
		return nil
	}
	*res = TurnResult{Turn: stream.result.Turn, Done: true, Res: stream.result.Res}
	b.stream = nil
	close(stream.released)
	return nil
}

type SaveResult struct {
	Turn int
	Res  [][]uint8
}
type QuitResult struct {
	Turn int
	Res  [][]uint8
}
type PauseUnpauseResult struct {
	Turns   int
	IsPause bool
}
type CellCountResult struct {
	Turn  int
	Count int
}

func (b *Broker) ProcessPauseUnpause(_ int, res *PauseUnpauseResult) error {
	fmt.Println("Processing pause/unpause")
	b.Io.KeyPresses.PauseUnpauseSig <- true
	pauseUnpauseRes := <-b.Io.Results.PauseUnpauseResult
	*res = PauseUnpauseResult{
		Turns:   pauseUnpauseRes.Turns,
		IsPause: pauseUnpauseRes.IsPause,
	}
	fmt.Println("Finished processing pause/unpause")
	return nil
}

func (b *Broker) ProcessQuit(_ int, res *QuitResult) error {
	b.Io.KeyPresses.QuitSig <- true
	quitRes := <-b.Io.Results.QuitResult
	*res = QuitResult{
		Turn: quitRes.Turn,
		Res:  quitRes.World,
	}
	return nil
}

func (b *Broker) ProcessSave(_ int, res *SaveResult) error {
	b.Io.KeyPresses.SaveSig <- true
	saveRes := <-b.Io.Results.SaveResult
	*res = SaveResult{
		Turn: saveRes.Turn,
		Res:  saveRes.World,
	}
	return nil
}

func (b *Broker) ProcessCellCount(_ int, res *CellCountResult) error {
	// Counts remain available even if the final turn finishes during this RPC.
	if b.Io.LiveView != nil {
		snapshot := b.Io.LiveView.Snapshot(-1)
		count := 0
		for _, row := range snapshot.World {
			for _, cell := range row {
				if cell == 255 {
					count++
				}
			}
		}
		*res = CellCountResult{Turn: snapshot.Turn, Count: count}
		return nil
	}
	b.Io.Ticker <- true
	count := <-b.Io.Results.CellCountResult
	*res = CellCountResult{Turn: count.Turn, Count: count.Count}
	return nil
}

// Snapshot the latest completed turn; unchanged frames carry no board data.
func (b *Broker) ProcessLiveView(lastTurn int, res *CompleteResult) error {
	if b.Io.LiveView == nil {
		return errors.New("live view is not initialised")
	}
	snapshot := b.Io.LiveView.Snapshot(lastTurn)
	*res = CompleteResult{Turn: snapshot.Turn, Res: snapshot.World}
	return nil
}

// Stop and return the final snapshot before the controller saves it.
func (b *Broker) ProcessKill(_ int, res *QuitResult) error {
	if err := b.ProcessQuit(0, res); err != nil {
		return err
	}
	b.shutdownRequested.Store(true)
	return nil
}

// The controller calls this only after writing the final PGM.
func (b *Broker) ProcessShutdown(_ int, res *bool) error {
	if !b.shutdownRequested.Load() {
		return errors.New("kill must be requested before shutdown")
	}
	if err := gol.ShutdownWorkers(); err != nil {
		return err
	}
	*res = true
	return b.listener.Close()
}

// main is the function called when starting Game of Life with 'go run .'
func main() {
	fmt.Println("Starting server...")

	// var mtx sync.RWMutex
	// conns := make(map[int]net.Conn)
	saveSig := make(chan bool, 1)
	pauseUnpauseSig := make(chan bool, 1)
	quitSig := make(chan bool, 1)
	keyPresses := gol.KeyChannels{
		SaveSig:         saveSig,
		PauseUnpauseSig: pauseUnpauseSig,
		QuitSig:         quitSig,
	}

	completeRes := make(chan gol.TurnWorldPair, 1)
	quitRes := make(chan gol.TurnWorldPair, 1)
	saveRes := make(chan gol.TurnWorldPair, 1)
	cellCountRes := make(chan gol.TurnCountPair, 1)
	pauseUnpauseRes := make(chan gol.PauseUnpauseResult, 1)
	results := gol.ResultChannels{
		CompleteResult:     completeRes,
		QuitResult:         quitRes,
		SaveResult:         saveRes,
		CellCountResult:    cellCountRes,
		PauseUnpauseResult: pauseUnpauseRes,
	}
	ticker := make(chan bool, 1)
	io := gol.IoChannels{
		Results:    results,
		KeyPresses: keyPresses,
		Ticker:     ticker,
		LiveView:   &gol.LiveView{},
	}
	broker := Broker{
		// mtx:   &mtx,
		// conns: conns,
		Io: io,
	}
	rpc.Register(&broker)

	go sigint()

	if len(os.Args) == 1 {
		panic("Not enough arguments")
	}
	port := os.Args[1]
	listener, err := net.Listen("tcp", ":"+port)
	fmt.Println("Listening on port ", port)
	if err != nil {
		log.Fatal(err)
	}
	broker.listener = listener
	// Wait for the shutdown RPC reply to be delivered before main returns.
	var connections sync.WaitGroup
	for {
		conn, err := listener.Accept()
		if err != nil {
			if !errors.Is(err, net.ErrClosed) {
				log.Print(err)
			}
			break
		}
		connections.Go(func() { defer conn.Close(); rpc.ServeConn(conn) })
	}
	connections.Wait()
}

func sigint() {
	sigint := make(chan os.Signal, 1)
	signal.Notify(sigint, syscall.SIGINT, syscall.SIGTERM)
	var exit atomic.Bool
	for range sigint {
		if exit.Load() {
			log.Printf("[Main] %v Force quit by the user", util.Yellow("WARN"))
			os.Exit(0)
		} else {
			log.Printf("[Main] %v Press Ctrl+C again to force quit", util.Yellow("WARN"))
			exit.Store(true)
			go func() {
				time.Sleep(4 * time.Second)
				exit.Store(false)
			}()
		}
	}
}
