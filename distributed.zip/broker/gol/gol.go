package gol

import (
	"fmt"
	"net/rpc"
	"os"
	"strings"
	"uk.ac.bris.cs/gameoflife/util"
)

// Params provides the details of how to run the Game of Life and which image to load.
type Params struct {
	Turns       int
	Threads     int
	ImageWidth  int
	ImageHeight int
}
type KeyChannels struct {
	SaveSig         chan bool
	PauseUnpauseSig chan bool
	QuitSig         chan bool
}

// FOR PARALLEL DOUBLE BUFFER
func defaultWorker(slice [][]uint8, resChan chan [][]uint8) {
	resChan <- calculateResultSliceForWorker(slice)
}
func defaultWorkerSingleThread(p Params, world [][]uint8, res [][]uint8) {
	calculateNextState(p, world, res)
}
func distributeWithDoubleBuffer(p Params, world [][]uint8, c distributorChannels, keyPresses KeyChannels) {

	world2 := Make2DSlice(p.ImageWidth, p.ImageHeight)
	doubleBufferTurnFn := func(p Params, world *[][]uint8) {
		startWorkersDoubleBuffer(p, *world, world2, defaultWorkerSingleThread, defaultWorker)
		*world, world2 = world2, *world
	}

	distributor(p, world, c, keyPresses, doubleBufferTurnFn)
}

// FOR PARALLEL MAP REDUCE
func mapReduceDefaultWorker(threadNumber int, startY int, slice [][]uint8, resChan chan util.Cell) {
	cs := calculateFlippedCellsForWorkerMapReduce(slice, startY)
	for i := 0; i < len(cs); i++ {
		resChan <- cs[i]
	}
}
func mapReduceDefaultWorkerSingleThread(p Params, world [][]uint8) []util.Cell {
	return calculateCellsFlippedMapReduce(p, world)
}

func distributeWithMapReduce(p Params, world [][]uint8, c distributorChannels, keyPresses KeyChannels) {
	cellsFlippedBuffer := make([]util.Cell, 0)
	mapReduceTurnFn := func(p Params, world *[][]uint8) {
		size := 0
		startWorkersMapReduce(p, *world, mapReduceDefaultWorkerSingleThread, mapReduceDefaultWorker, &cellsFlippedBuffer, &size)
	}

	distributor(p, world, c, keyPresses, mapReduceTurnFn)
}

type WorkerArgs struct {
	StartY int
	Slice  [][]uint8
}

func mapReduceDistributedWorker(client *rpc.Client, startY int, slice [][]uint8, resChan chan util.Cell) {
	var flippedCells []util.Cell
	args := WorkerArgs{
		StartY: startY,
		Slice:  slice,
	}
	client.Call("Worker.ProcessSliceMapReduce", args, &flippedCells)
	for _, cell := range flippedCells {
		resChan <- cell
	}
}
func distributeWithDistributedMapReduce(p Params, world [][]uint8, c distributorChannels, keyPresses KeyChannels) {
	cellsFlippedBuffer := make([]util.Cell, 0)

	workerFile, err := os.ReadFile("workerURLs.txt")
	if err != nil {
		panic("workerURLs.txt could not be found")
	}
	workerNames := strings.Fields(string(workerFile))
	if len(workerNames) == 0 {
		panic("workerURLs.txt contains no workers")
	}
	clients := make([]*rpc.Client, 0, len(workerNames))
	for _, workerName := range workerNames {
		client, err := rpc.Dial("tcp", workerName)
		if err != nil {
			panic("Failed to connect to worker at " + "(" + workerName + ")")
		}

		defer client.Close()
		clients = append(clients, client)
	}
	pDist := Params{
		Threads:     len(clients),
		ImageHeight: p.ImageHeight,
		ImageWidth:  p.ImageWidth,
		Turns:       p.Turns,
	}

	mapReduceTurnFn := func(p Params, world *[][]uint8) {
		worker := func(workerNumber int, startY int, slice [][]uint8, resChan chan util.Cell) {
			mapReduceDistributedWorker(clients[workerNumber], startY, slice, resChan)
		}
		size := 0
		startWorkersMapReduce(p, *world, mapReduceDefaultWorkerSingleThread, worker, &cellsFlippedBuffer, &size)
		if c.turns != nil {
			// The reducer reuses its buffer; the RPC stream owns this copy.
			c.turns <- append([]util.Cell(nil), cellsFlippedBuffer[:size]...)
		}
	}

	distributor(pDist, world, c, keyPresses, mapReduceTurnFn)
}

// Run starts the processing of Game of Life. It should initialise channels and goroutines.
func Run(p Params, world [][]uint8, io IoChannels) {
	fmt.Println("Workers requested: ", p.Threads)

	distributorChannels := distributorChannels{
		results:  io.Results,
		ticker:   io.Ticker,
		liveView: io.LiveView,
		turns:    io.Turns,
	}

	// TODO uncomment the preferred function below (and comment out the rest)
	distributeWithDistributedMapReduce(p, world, distributorChannels, io.KeyPresses)
	// distributeWithMapReduce(p, distributorChannels, keyPresses)
}

// ShutdownWorkers is called after the controller has saved the final snapshot.
func ShutdownWorkers() error {
	data, err := os.ReadFile("workerURLs.txt")
	if err != nil {
		return err
	}
	var failures []string
	for _, address := range strings.Fields(string(data)) {
		client, err := rpc.Dial("tcp", address)
		if err == nil {
			var stopped bool
			err = client.Call("Worker.Shutdown", 0, &stopped)
			client.Close()
		}
		if err != nil {
			failures = append(failures, address+": "+err.Error())
		}
	}
	if len(failures) != 0 {
		return fmt.Errorf("worker shutdown failed: %s", strings.Join(failures, "; "))
	}
	return nil
}
